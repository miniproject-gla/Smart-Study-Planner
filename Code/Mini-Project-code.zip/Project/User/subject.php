<?php


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      
    </style>
</head>
<body>
    <?php include 'header.php';
    if(isset($_POST['rid']))
    {
    $rid=$_POST['rid'];
    $_SESSION['RID']=$rid;
    }
    $rid=$_SESSION['RID'];
    ?>

<!-- Inputs with icons -->
<h4
              class="mb-4 text-lg font-semibold text-gray-600 dark:text-gray-300"
            >
              Icons 
            </h4>
            <div
              class="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800"
            >
              <label class="block text-sm">
                <form action="backend.php" method="post">
                                    <!-- focus-within sets the color for the icon when input is focused -->
                <div
                  class="flex row text-gray-500 focus-within:text-purple-600 dark:focus-within:text-purple-400"
                >
                <label class="align-middle mt-2">Subject </label>
                  <input
                  type="text"
                  name="name"
                    class="block w-1/4 pl-10 mt-1 ml-2 text-sm text-black dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray form-input"
                    placeholder="Enter Subject Name"
                  />
                  <label class="align-middle mt-2 ml-2">Difficulty</label>
                  <input
                  type="range"
                  name="diff"
                  min="1" max="100" value="50"
                    class="block w-1/4  ml-2 text-sm text-black "
                    id="myRange"
                  />
                  <label class="align-middle mt-2 ml-2">Diff:-</label>
                  <span id="demo" class="align-middle mt-2 ml-2"></span>
                  <label class="align-middle mt-2 ml-2">Priority</label>
                  <input
                  type="range"
                  name="prio"
                  min="1" max="100" value="50"
                  class="block w-1/4   ml-2 text-sm text-black "
                  id="myRange1"
                  />
                  <label class="align-middle mt-2 ml-2">Diff:-</label>
                  <span id="demo1" class="align-middle mt-2 ml-2"></span>

                  <button type="submit" name="rid" value="<?php echo $rid; ?>"class="px-4 py-2 ml-2 text-sm font-medium leading-5 text-white transition-colors duration-150 bg-purple-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-purple-700 focus:outline-none focus:shadow-outline-purple">Add</button>
                </div>
                </form>

              </label>

                               
            </div>



    <h4
              class="mb-4 text-lg font-semibold text-gray-600 dark:text-gray-300"
            >
              Table with actions 
              
            </h4>
            <div class="w-full overflow-hidden rounded-lg shadow-xs">
              <div class="w-full overflow-x-auto">
                <table class="w-full whitespace-no-wrap">
                  <thead>
                    <tr
                      class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800"
                    >
                      <th class="px-4 py-3">Subject </th>
                      <th class="px-4 py-3">Hardness </th>
                      <th class="px-4 py-3">Priority </th>
                      <th class="px-4 py-3">Study Time</th>
                      <th class="px-4 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody
                    class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800"
                  >
                  <?php  
                    $sql="SELECT * from subjects Where RID='$rid'";
                    $result=mysqli_query($conn,$sql);
                    $n=0;
                    while($row=mysqli_fetch_assoc($result))
                    
                    {

                    ?>
                    <tr class="text-gray-700 dark:text-gray-400">
                      <td class="px-4 py-3">
                        <div class="flex items-center text-sm">
                          <!-- Avatar with inset shadow -->
                        
                          <div>
                            <p class="font-semibold"><?php echo $row['Subject'];?></p>
                            
                          </div>
                        </div>
                      </td>
                      <td class="px-4 py-3 text-sm">
                      <?php echo $row['Hardness'];?>
                      </td>
                      <td class="px-4 py-3 text-xs">
                        <span
                          class="px-2 py-1 font-semibold leading-tight text-green-700 bg-green-100 rounded-full dark:bg-green-700 dark:text-green-100"
                        >
                        <?php echo $row['Priority'];?>
                        </span>
                      </td>
                      <td class="px-4 py-3 text-sm">
                      <?php echo $row['Rtime'];?>
                      </td>
                      <td class="px-4 py-3">
                        <div >
                          <form action="backend.php" method="post" class="flex items-center space-x-4 text-sm">
                          <button
                            class="flex items-center justify-between px-2 py-2 text-sm font-medium leading-5 text-purple-600 rounded-lg dark:text-gray-400 focus:outline-none focus:shadow-outline-gray"
                            aria-label="Edit"
                          >
                            <svg
                              class="w-5 h-5"
                              aria-hidden="true"
                              fill="currentColor"
                              viewBox="0 0 20 20"
                            >
                              <path
                                d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"
                              ></path>
                            </svg>
                          </button>
                          <button
                          type="submit" name="delete_subject" value="<?php echo $row['ID'];?>"
                            class="flex items-center justify-between px-2 py-2 text-sm font-medium leading-5 text-purple-600 rounded-lg dark:text-gray-400 focus:outline-none focus:shadow-outline-gray"
                            aria-label="Delete"
                          >
                            <svg
                              class="w-5 h-5"
                              aria-hidden="true"
                              fill="currentColor"
                              viewBox="0 0 20 20"
                            >
                              <path
                                fill-rule="evenodd"
                                d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                                clip-rule="evenodd"
                              ></path>
                            </svg>
                          </button>
                          </form>
                        </div>
                      </td>
                    </tr>

                    
                    <?php } ?>
                    
                    
                    
                </tbody>
                
                </table>
                
            </div>   
    </div>
 
        


<h4 class="mb-4 text-lg font-semibold text-gray-600 dark:text-gray-300">
              Time Table 
              
            </h4>
  
 
<div class="w-full overflow-hidden rounded-lg shadow-xs">
              <div class="w-full overflow-x-auto">
                <table class="w-full whitespace-no-wrap">
                  <thead>
                    <tr
                      class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800"
                    >
                      <th class="px-4 py-3">Monday </th>
                      <th class="px-4 py-3">Tuesday </th>
                      <th class="px-4 py-3">Wednesday </th>
                      <th class="px-4 py-3">Thursday </th>
                      <th class="px-4 py-3">Friday </th>
                      <th class="px-4 py-3">Saturday</th>
                      <th class="px-4 py-3">Sunday</th>
                    </tr>
                  </thead>
                  <tbody
                    class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800"
                  >
                  <?php 
                  $sql="SELECT * from subjects Where RID='$rid' ORDER By Score DESC";
                  $result=mysqli_query($conn,$sql);
                  $n=0;
                  while($row=mysqli_fetch_assoc($result))
                  
                  {
                    $sub[$n]= $row['Subject'];
                    $n++;
                  }
$x=0;
$y=$n-1;      

if($n==2)
{
  $k=2;
}
else if($n>4)
{
  $k=4;
}else if($n>7){
  $k=5;
  }else if($n==1){
    $k=1;
    }
  else{
    $k=3;
  }

  if($n==NULL)
  {
    echo "Nothing To Display";
  }else{
                  while($x<$k)
                  {

                  
                  ?>
                    
                    <tr class="text-gray-700 dark:text-gray-400">
                      <td class="px-4 py-3">
                        <div class="flex items-center text-sm">
                          <!-- Avatar with inset shadow -->
                        
                          <p><?php echo $sub[$x];?></p>
                                               
                        </div>
                      </td>
                      <td class="px-4 py-3 text-sm">
                      <?php echo $sub[$y];?>
                      </td>
                      <td class="px-4 py-3 text-xs">
                       
                        <?php echo $sub[$x];?>
                        
                      </td>
                      <td class="px-4 py-3 text-sm">
                      <?php echo $sub[$y];?>
                      </td>
                     
                      <td class="px-4 py-3 text-sm">
                      <?php echo $sub[$x];?>
                      </td>
                     
                      <td class="px-4 py-3 text-sm">
                      <?php echo $sub[$y];?>
                      </td>
                     
                      <td class="px-4 py-3 text-sm">
                      <?php echo $sub[$x];?>
                      </td>
                     
                    </tr>

                    <?php $x++;
                  $y--;
                  }}?>
                 
                    
                    
                    
                </tbody>
                
                </table>

              <script>
var slider = document.getElementById("myRange");
var output = document.getElementById("demo");
output.innerHTML = slider.value;

slider.oninput = function() {
  output.innerHTML = this.value;
}


var slider1 = document.getElementById("myRange1");
var output1 = document.getElementById("demo1");
output1.innerHTML = slider1.value;

slider1.oninput = function() {
  output1.innerHTML = this.value;
}

function getTimeDateCustom() {
  document.getElementById("liveTimeStr").value = "22:53:05";
}

</script>

    <?php include 'footer.php';?>
    
</body>
</html>