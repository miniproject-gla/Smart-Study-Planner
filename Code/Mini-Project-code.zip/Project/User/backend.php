<?php 
session_start();
include '../config.php';


if(isset($_POST['register']))
{
   
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];

    $sql="SELECT * from user WHERE Email='$email'";
    $result=mysqli_query($conn,$sql);
    $present=mysqli_num_rows($result);

    if($present>0)
    {
    echo "duplicate email";
    }else{


    $query="INSERT INTO user (Name,Email, Password)values('$name','$email','$password')";
        $results=mysqli_query($conn,$query);

        if($results==true)
        {
            $sql="SELECT * from user WHERE Email='$email' AND Password='$password'";
            $result=mysqli_query($conn,$sql);
            $row=mysqli_fetch_array($result);

            $_SESSION['ID']=$row['ID'];
            $_SESSION['email']=$row['Email'];
            header('Location:Dashboard.php');
        }else{
            header('Location:404.html');
        }
    }
}


if(isset($_POST['login']))
{
    $email=$_POST['email'];
    $password=$_POST['password'];

    $sql="SELECT * from user WHERE Email='$email' AND Password='$password'";
    $result=mysqli_query($conn,$sql);
    $present=mysqli_num_rows($result);

    if($present>0)
    {
        $row=mysqli_fetch_array($result);

        $_SESSION['ID']=$row['ID'];
        $_SESSION['email']=$row['Email'];
        header('Location:Dashboard.php');

    }else{
echo "wrong id pass";

}
}


if(isset($_POST['create_routine']))
{
    $id=$_SESSION['ID'];
    $name=$_POST['name'];

    $sql="INSERT INTO routine(UID,NAME)values('$id','$name')";
    $result=mysqli_query($conn,$sql);
    
    if($result==true)
    {
        header('Location:routine.php');
    }

}

if(isset($_POST['prio']))
{
    $name=$_POST['name'];
    $diff=$_POST['diff'];
    $prio=$_POST['prio'];
    $rid=$_POST['rid'];
   
    $hardness=$diff/2;
    $priority=$prio/2;
    $score=$hardness+$priority; 
   
    $sql="INSERT INTO subjects(RID,Subject,Hardness,Priority,Score)value('$rid','$name','$diff','$prio','$score')";
   $result=mysqli_query($conn,$sql);
   if($result==TRUE)
   $sql="SELECT * from subjects Where RID=$rid";
   $result=mysqli_query($conn,$sql);
   
   while($row=mysqli_fetch_assoc($result))
   {
   $id=$row['ID'];
   $score=$row['Score'];

   if($score<=25)
   {
       $rtime=3;
   }else if($score>25 and $score<=50)
   {
       $rtime=5;
   }else if($score>50 and $score<=75)
   {
       $rtime=7;
   }else if($score>75)
   {
       $rtime=9;
   }else{
       echo "Something went wrong";
   }

   $query="UPDATE subjects SET Rtime='$rtime' Where ID='$id'";
   $results=mysqli_query($conn,$query);
}

    header('Location:subject.php');
}
 else{
    echo "Failed to insert";
}

if(isset($_POST['delete_subject']))
{
    $id=$_POST['delete_subject'];

    $sql="DELETE FROM subjects WHERE ID = '$id'";
    $result=mysqli_query($conn,$sql);

    if($result==TRUE)
    {
        header('Location:subject.php');
    }else{
        header('Location:subject.php');
    }
}






if(isset($_POST['update_profile']))
{
    $f=$_FILES["pic"];
    $filename=$f['name'];
    $filepath=$f['tmp_name'];
    $destfile='upload/'.$filename;
    move_uploaded_file($filepath,$destfile);

    $name=$_POST['name'];
    $id=$_SESSION['ID'];

    $query="UPDATE user SET Pic='$destfile' , Name='$name' Where ID='$id'";
    $results=mysqli_query($conn,$query);

    if($results==TRUE)
    {
        header('Location:profile.php');
    }else{
        header('Location:profile.php');
    }

}



?>