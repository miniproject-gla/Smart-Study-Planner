<?php


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php include 'header.php';?>
<?php
    if(isset($_POST['rid']))
    {
    $rid=$_POST['rid'];
    $_SESSION['RID']=$rid;
    }
    $rid=$_SESSION['RID'];
    ?>
    <h4 class="mb-4 text-lg font-semibold text-gray-600 dark:text-gray-300">
              Time Table 
              
            </h4>
  
 
<div class="w-full overflow-hidden rounded-lg shadow-xs">
              <div class="w-full overflow-x-auto">
                <table class="w-full whitespace-no-wrap">
                  <thead>
                    <tr
                      class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800"
                    >
                      <th class="px-4 py-3">Monday </th>
                      <th class="px-4 py-3">Tuesday </th>
                      <th class="px-4 py-3">Wednesday </th>
                      <th class="px-4 py-3">Thursday </th>
                      <th class="px-4 py-3">Friday </th>
                      <th class="px-4 py-3">Saturday</th>
                      <th class="px-4 py-3">Sunday</th>
                    </tr>
                  </thead>
                  <tbody
                    class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800"
                  >
                  <?php 
                  $sql="SELECT * from subjects Where RID='$rid' ORDER By Score DESC";
                  $result=mysqli_query($conn,$sql);
                  $n=0;
                  while($row=mysqli_fetch_assoc($result))
                  
                  {
                    $sub[$n]= $row['Subject'];
                    $n++;
                  }
$x=0;
$y=$n-1;      

if($n==2)
{
  $k=2;
}
else if($n>4)
{
  $k=4;
}else if($n>7){
  $k=5;
  }else if($n==1){
    $k=1;
    }
  else{
    $k=3;
  }

  if($n==NULL)
  {
    echo "Nothing To Display";
  }else{
                  while($x<$k)
                  {

                  
                  ?>
                    
                    <tr class="text-gray-700 dark:text-gray-400">
                      <td class="px-4 py-3">
                        <div class="flex items-center text-sm">
                          <!-- Avatar with inset shadow -->
                        
                          <p><?php echo $sub[$x];?></p>
                                               
                        </div>
                      </td>
                      <td class="px-4 py-3 text-sm">
                      <?php echo $sub[$y];?>
                      </td>
                      <td class="px-4 py-3 text-xs">
                       
                        <?php echo $sub[$x];?>
                        
                      </td>
                      <td class="px-4 py-3 text-sm">
                      <?php echo $sub[$y];?>
                      </td>
                     
                      <td class="px-4 py-3 text-sm">
                      <?php echo $sub[$x];?>
                      </td>
                     
                      <td class="px-4 py-3 text-sm">
                      <?php echo $sub[$y];?>
                      </td>
                     
                      <td class="px-4 py-3 text-sm">
                      <?php echo $sub[$x];?>
                      </td>
                     
                    </tr>

                    <?php $x++;
                  $y--;
                  }}?>
                 
                    
                    
                    
                </tbody>
                
                </table>
<script type="text/javascript">
  function changeAtiveTab(event,tabID){
    let element = event.target;
    while(element.nodeName !== "A"){
      element = element.parentNode;
    }
    ulElement = element.parentNode.parentNode;
    aElements = ulElement.querySelectorAll("li > a");
    tabContents = document.getElementById("tabs-id").querySelectorAll(".tab-content > div");
    for(let i = 0 ; i < aElements.length; i++){
      aElements[i].classList.remove("text-black");
      aElements[i].classList.remove("bg-pink-600");
      aElements[i].classList.add("text-pink-600");
      aElements[i].classList.add("bg-grey");
      tabContents[i].classList.add("hidden");
      tabContents[i].classList.remove("block");
    }
    element.classList.remove("text-pink-600");
    element.classList.remove("bg-grey");
    element.classList.add("text-black");
    element.classList.add("bg-pink-600");
    document.getElementById(tabID).classList.remove("hidden");
    document.getElementById(tabID).classList.add("block");
  }
</script>

    <?php include 'footer.php';?>
    
</body>
</html>