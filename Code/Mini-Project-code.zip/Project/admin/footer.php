<?php 


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      
<div class="footer">
		
        <div class="copyright">
            <p>© Designed &amp; by <a href="#" target="_blank">Smart Study planner</a> 2022</p>
        </div>
    </div>
     
</div> 
<script src="js/global.min.js"></script>
<script src="js/custom.min.js"></script>
<script src="js/dlabnav-init.js"></script>
</body>
</html>