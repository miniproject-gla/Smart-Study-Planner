<?php 

$conn=mysqli_connect('localhost','root','','ssp');

if($conn==false)
{
    echo "Error connecting";
}


?>