<?php
include('config.php');


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<script src="https://cdn.tailwindcss.com"></script>
<body>
    
<h1 class="font-bold text-2xl ">Add Subject Form</h1>

<form action="backend.php" method="post" >
    <h4>Name:</h4>
 <input type="text" name="name" class="border border-2 border-black rounded h-6"/>
 <br>
<h4>Difficulty:</h4>
 <input type="range" name="diff" min="1" max="100" value="50" class="slider" id="myRange" />
 <p>Value: <span id="demo"></span></p> 
 <h4>Priority:</h4>
 <input type="range" name="prio" min="1" max="100" value="50" class="slider" id="myRange1"/>   
 <p>Value: <span id="demo1"></span></p> 

 <button type="submit" name="add_subject" class="border border-indigo-500 bg-indigo-500 text-white rounded-md px-4 py-2 m-2 transition duration-500 ease select-none hover:bg-indigo-600 focus:outline-none focus:shadow-outline">Submit</button>
</form>



<h1 class="font-bold text-2xl text-center">Subject </h1>

<table class="border border-black mx-auto mt-2 ">
    <thead>
        <tr>
            <td class="border border-black">*</td>
            <td class="border border-black ">Subject Name</td>
            <td class="border border-black ">Hardness</td>
            <td class="border border-black ">Priority</td>
            <td class="border border-black ">Score</td>
            <td class="border border-black ">Study Time Alloted</td>
        </tr>
    </thead>
    <tbody>
        <?php 

$sql="SELECT * from subjects Where RID='1'";
$result=mysqli_query($conn,$sql);
$n=0;
while($row=mysqli_fetch_assoc($result))

{

?>
    <tr>
    <td><?php echo $n;?></td>
            <td class="border border-black "><?php echo $row['Subject'];?></td>
            <td class="border border-black "><?php echo $row['Hardness'];?></td>
            <td class="border border-black "><?php echo $row['Priority'];?></td>
            <td class="border border-black "><?php echo $row['Score'];?></td>
            <td class="border border-black "><?php if($row['Rtime']==NULL){
                
                echo "--";
            } else {
                echo $row['Rtime'];
            }
           ?> 
            </td>
        </tr>

        <?php 
    $n++;
    } ?>
    </tbody>
</table>
<form method="post" action="backend.php">
    <center>
    <button type="submit" name="create" class="text-gray-900 mt-5 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">Generate  Time Allotment </button>
    </center>
</form>

<h1 class="font-bold text-2xl text-center m-5">Add Free time slots</h1>

<form>
    Day:-<select >
        <option value="">Monday</option>
        <option value="">Tuesday</option>
    </select>

    Start Time:-
    <input type="time" id="appt" name="appt"
       min="01:00" max="24:00" required>
    End Time:-
    <input type="time" id="myInput1" oninput="myFunction()" />



    <span id="dis"></span>
    <button type="submit" name="create" class="text-gray-900 mt-5 bg-white border border-gray-300 focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700">Submit details</button>
    </center>
</form>





<script>
var slider = document.getElementById("myRange");
var output = document.getElementById("demo");
output.innerHTML = slider.value;

slider.oninput = function() {
  output.innerHTML = this.value;
}


var slider1 = document.getElementById("myRange1");
var output1 = document.getElementById("demo1");
output1.innerHTML = slider1.value;

slider1.oninput = function() {
  output1.innerHTML = this.value;
}

function getTimeDateCustom() {
  document.getElementById("liveTimeStr").value = "22:53:05";
}

</script>


</body>
</html>