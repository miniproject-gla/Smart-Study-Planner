<?php
session_start();
include('config.php');

if(isset($_POST['prio']))
{
    $name=$_POST['name'];
    $diff=$_POST['diff'];
    $prio=$_POST['prio'];
   
    $hardness=$diff/2;
    $priority=$prio/2;
    $score=$hardness+$priority; 
   
    $sql="INSERT INTO subjects(RID,Subject,Hardness,Priority,Score)value('1','$name','$diff','$prio','$score')";
   $result=mysqli_query($conn,$sql);
   if($result==TRUE)
    header('Location:add_subject.php');
 else
    echo "Failed to insert";
}

if(isset($_POST['create']))
{
    $rid=1;
    
    $sql="SELECT * from subjects Where RID=$rid";
    $result=mysqli_query($conn,$sql);
    
    while($row=mysqli_fetch_assoc($result))
    {
    $id=$row['ID'];
    $score=$row['Score'];

    if($score<=25)
    {
        $rtime=3;
    }else if($score>25 and $score<=50)
    {
        $rtime=5;
    }else if($score>50 and $score<=75)
    {
        $rtime=7;
    }else if($score>75)
    {
        $rtime=9;
    }else{
        echo "Something went wrong";
    }

    $query="UPDATE subjects SET Rtime='$rtime' Where ID='$id'";
    $results=mysqli_query($conn,$query);
}

header('Location:add_subject.php');
}

?>