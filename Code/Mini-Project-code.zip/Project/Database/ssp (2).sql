-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2022 at 08:13 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ssp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `AID` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(32) NOT NULL,
  `Approval` varchar(20) NOT NULL,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `Time` time NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`AID`, `Name`, `Email`, `Password`, `Approval`, `Date`, `Time`) VALUES
(1, 'Vidhan', 'Admin@gmail.com', '1234', 'Approved', '2022-11-24', '00:00:00'),
(3, 'vaibhav', '', '', 'approved', '2022-11-24', '16:57:36');

-- --------------------------------------------------------

--
-- Table structure for table `routine`
--

CREATE TABLE `routine` (
  `RID` int(11) NOT NULL,
  `UID` varchar(10) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `Time` time NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `routine`
--

INSERT INTO `routine` (`RID`, `UID`, `Name`, `Date`, `Time`) VALUES
(1, '1', 'routine 1', '2022-11-28', '08:15:20'),
(2, '1', 'routine 2', '2022-11-28', '08:19:03'),
(3, '1', 'routine 3', '2022-11-28', '08:19:12'),
(4, '1', 'routine 4', '2022-11-28', '08:46:27'),
(5, '1', 'routine 5', '2022-11-28', '08:46:35');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `ID` int(11) NOT NULL,
  `RID` varchar(10) NOT NULL,
  `Subject` varchar(30) NOT NULL,
  `Hardness` varchar(10) NOT NULL,
  `Priority` varchar(10) NOT NULL,
  `Score` varchar(10) NOT NULL,
  `Rtime` varchar(10) NOT NULL,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `Time` time NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`ID`, `RID`, `Subject`, `Hardness`, `Priority`, `Score`, `Rtime`, `Date`, `Time`) VALUES
(19, '2', 'routine 2', '8', '80', '44', '', '2022-11-28', '11:45:34'),
(20, '2', 'xcvb', '77', '71', '74', '', '2022-11-28', '11:48:22'),
(21, '2', 'sst', '74', '77', '75.5', '', '2022-11-28', '14:30:21'),
(27, '1', 'maths', '74', '72', '73', '7', '2022-12-06', '00:02:02'),
(28, '1', 'science', '18', '12', '15', '3', '2022-12-06', '00:02:12'),
(29, '1', 'hindi', '76', '85', '80.5', '9', '2022-12-06', '00:02:23'),
(30, '1', 'Eng', '25', '13', '19', '3', '2022-12-06', '00:02:40'),
(31, '1', 'bio', '23', '20', '21.5', '3', '2022-12-06', '00:06:09'),
(32, '1', 'chem', '81', '73', '77', '9', '2022-12-06', '00:06:23');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(32) NOT NULL,
  `Approval` varchar(10) NOT NULL,
  `Pic` varchar(255) NOT NULL,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `Time` time NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `Name`, `Email`, `Password`, `Approval`, `Pic`, `Date`, `Time`) VALUES
(1, 'Vidhan', 'vidhan@gmail.com', '1234', 'approved', 'upload/Screenshot (6).png', '2022-11-24', '00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`AID`);

--
-- Indexes for table `routine`
--
ALTER TABLE `routine`
  ADD PRIMARY KEY (`RID`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `AID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `routine`
--
ALTER TABLE `routine`
  MODIFY `RID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
